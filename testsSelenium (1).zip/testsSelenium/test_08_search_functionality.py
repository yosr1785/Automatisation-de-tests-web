"""
=========================================================================
TC-008 [F-03] - Recherche par mot-clé "baklawa"
Statut attendu : PASS

Lancement :
    pytest test_08_search_functionality.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test08SearchFunctionality(BaseTest):

    def test_08_search_functionality(self):
        driver = self.driver
        wait   = self.wait
        PAUSE  = 2

        # ── 1. Navigation ──────────────────────────────────────────────────
        print("\n[TC-008] Navigation vers la page d'accueil...")
        driver.get("https://patisserieaicha.tn")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        time.sleep(PAUSE * 2)

        # ── 2. Ouverture de la barre de recherche ──────────────────────────
        print("[TC-008] Ouverture de la barre de recherche...")
        search_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//button[.//span[contains(@class,"magnifying-glass")]]')
        ))
        driver.execute_script("arguments[0].click();", search_btn)
        time.sleep(PAUSE)

        # ── 3. Saisie du mot clé ───────────────────────────────────────────
        print("[TC-008] Saisie du mot clé 'baklawa'...")
        search_input = wait.until(EC.visibility_of_element_located(
            (By.CSS_SELECTOR, "input.search-input")
        ))
        search_input.click()
        search_input.clear()
        search_input.send_keys("baklawa")
        time.sleep(PAUSE)

        # ── 4. Envoi et attente des résultats ──────────────────────────────
        print("[TC-008] Envoi de la recherche...")
        search_input.send_keys(Keys.RETURN)
        wait.until(EC.url_contains("baklawa"))
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "main div.grid")))
        time.sleep(PAUSE)

        # ── 5. Récupération des produits ───────────────────────────────────
        products = driver.find_elements(By.CSS_SELECTOR, "main div.grid > div")
        print(f"[TC-008] {len(products)} produit(s) trouvé(s)")

        # ── 6. Vérification du contenu ─────────────────────────────────────
        non_matching = [
            el.text.strip()
            for el in products
            if el.text.strip() and "baklawa" not in el.text.strip().lower()
        ]

        if non_matching:
            print(f"[TC-008] ⚠ Produits hors sujet : {non_matching}")
        else:
            print("[TC-008] ✓ Tous les produits contiennent 'baklawa'")

        # ── 7. Assertions ──────────────────────────────────────────────────
        self.assertGreater(
            len(products), 0,
            "BUG : Aucun produit affiché pour la recherche 'baklawa'"
        )
        self.assertEqual(
            non_matching, [],
            f"BUG : Produits hors sujet affichés : {non_matching}"
        )

        print("[TC-008] ✓ Test de recherche réussi")


if __name__ == '__main__':
    unittest.main(verbosity=2)
