"""
=========================================================================
TC-010 [F-03] - Tri par prix croissant
Statut attendu : PASS

Lancement :
    pytest test_10_sort_by_price_asc.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import TimeoutException

from base import BaseTest


class Test10SortByPriceAsc(BaseTest):

    def test_10_sort_by_price_asc(self):
        driver = self.driver
        wait   = self.wait
        PAUSE  = 2

        # ── 1. Navigation ──────────────────────────────────────────────────
        print("\n[TC-010] Navigation vers la catégorie Baklawa...")
        driver.get("https://patisserieaicha.tn/product-list/55458/baklawa/")
        wait.until(EC.presence_of_element_located(
            (By.XPATH, "//*[contains(@class,'product')]")
        ))
        time.sleep(PAUSE)

        # ── 2. Sélection du tri "Prix croissant" ───────────────────────────
        print("[TC-010] Sélection du tri par prix croissant...")
        try:
            sort_dropdown = wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, "select, [class*='sort'], [class*='tri']")
            ))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", sort_dropdown)
            time.sleep(PAUSE)

            select = Select(sort_dropdown)
            options = [o.text for o in select.options]
            print(f"[TC-010] Options disponibles : {options}")

            ASC_KEYWORDS  = ["croissant", "bas", "asc", "moins cher", "faible", "low"]
            DESC_KEYWORDS = ["décroissant", "desc", "élevé", "plus cher", "high"]

            option_asc = next(
                (o for o in options
                 if any(kw in o.lower() for kw in ASC_KEYWORDS)
                 and not any(kw in o.lower() for kw in DESC_KEYWORDS)),
                None
            )

            if option_asc:
                select.select_by_visible_text(option_asc)
                print(f"[TC-010] Option sélectionnée : '{option_asc}'")
            else:
                self.skipTest(f"Aucune option de tri croissant trouvée parmi : {options}")

        except TimeoutException:
            self.skipTest("Menu de tri introuvable sur la page")

        time.sleep(PAUSE * 2)

        # ── 3. Récupération des prix ───────────────────────────────────────
        print("[TC-010] Récupération des prix affichés...")
        price_elements = driver.find_elements(
            By.CSS_SELECTOR,
            "main [class*='price']:not([class*='old']):not([class*='ancien'])"
        )
        time.sleep(PAUSE)

        prices = []
        for el in price_elements:
            txt = ''.join(c for c in el.text if c.isdigit() or c in '.,')
            txt = txt.replace(',', '.')
            try:
                prices.append(float(txt))
            except ValueError:
                continue

        print(f"[TC-010] Prix extraits : {prices}")

        # ── 4. Assertions ──────────────────────────────────────────────────
        self.assertGreater(
            len(prices), 1,
            f"Pas assez de prix récupérés ({len(prices)}) — sélecteur à revoir"
        )
        self.assertEqual(
            prices, sorted(prices),
            f"BUG : Tri prix croissant invalide\nObtenu  : {prices}\nAttendu : {sorted(prices)}"
        )

        print(f"[TC-010] ✓ Tri croissant vérifié : {prices[:5]}...")


if __name__ == '__main__':
    unittest.main(verbosity=2)
