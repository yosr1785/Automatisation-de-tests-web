"""
=========================================================================
TC-002 [F-01] - Tentatives de connexion illimitées (BUG-001)
Statut attendu : FAIL (aucun blocage / aucun captcha)

Lancement :
    pytest test_02_brute_force.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test02BruteForceNoBlock(BaseTest):

    def test_02_brute_force_no_block(self):
        driver = self.driver
        wait   = self.wait
        captcha_or_block_appeared = False

        for attempt in range(6):
            driver.get(self.login_url)
            time.sleep(2)

            email_field = wait.until(EC.presence_of_element_located((By.NAME, "email")))
            email_field.clear()
            time.sleep(0.5)
            email_field.send_keys("fakeuser@test.com")

            password_field = wait.until(EC.presence_of_element_located((By.NAME, "password")))
            password_field.clear()
            time.sleep(0.3)
            password_field.send_keys(f"wrongpassword_{attempt}")
            time.sleep(1)

            btn = wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, "button[type='submit']")
            ))
            driver.execute_script("arguments[0].click();", btn)
            time.sleep(2)

            page_src = driver.page_source.lower()
            if (
                "captcha"               in page_src
                or "compte bloqué"      in page_src
                or "trop de tentatives" in page_src
                or "too many attempts"  in page_src
            ):
                captcha_or_block_appeared = True
                print(f"[TC-002] Blocage détecté à la tentative {attempt + 1}")
                break

        self.assertTrue(
            captcha_or_block_appeared,
            "BUG-001 : aucun blocage/CAPTCHA après 10 tentatives échouées"
        )


if __name__ == '__main__':
    unittest.main(verbosity=2)
