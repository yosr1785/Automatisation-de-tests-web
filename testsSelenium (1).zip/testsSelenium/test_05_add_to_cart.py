"""
=========================================================================
TC-005 [F-02] - Ajout d'un produit au panier (Baklawa el Bey)
Statut attendu : PASS

Lancement :
    pytest test_05_add_to_cart.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from base import BaseTest


class Test05AddToCart(BaseTest):

    def test_05_add_to_cart(self):
        driver = self.driver
        wait   = self.wait

        self.login()
        driver.get("https://patisserieaicha.tn/product/55458/baklawa/409547/baklawa-el-bey")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "h1")))
        time.sleep(2)

        qty_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//button[contains(text(),'+')]")
        ))
        qty_btn.click()
        time.sleep(1)

        add_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[5]/div[2]/button')
        ))
        driver.execute_script("arguments[0].click();", add_btn)
        time.sleep(3)

        try:
            confirm = wait.until(EC.presence_of_element_located(
                (By.XPATH, "//*[contains(@id,'headlessui-dialog-panel')]//li//span")
            ))
            self.assertTrue(confirm.is_displayed())
            print(f"[TC-005] Confirmation : {confirm.text}")
        except TimeoutException:
            self.fail("Aucune notification ni mise à jour du compteur après ajout au panier")


if __name__ == '__main__':
    unittest.main(verbosity=2)
