"""
=========================================================================
TC-006 [F-02] - Quantité illimitée acceptée (BUG-002)
Statut attendu : FAIL (la quantité 1002 est acceptée sans alerte)

Lancement :
    pytest test_06_quantity_unlimited.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from base import BaseTest


class Test06QuantityUnlimited(BaseTest):

    def test_06_quantity_unlimited(self):
        driver = self.driver
        wait   = self.wait

        self._logout()
        self.login()
        driver.get("https://patisserieaicha.tn/product/55458/baklawa/409547/baklawa-el-bey")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "h1")))
        time.sleep(2)

        qty_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//button[contains(text(),'+')]")
        ))
        for _ in range(1002):
            driver.execute_script("arguments[0].click();", qty_btn)

        time.sleep(1)

        add_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[5]/div[2]/button')
        ))
        driver.execute_script("arguments[0].click();", add_btn)
        time.sleep(3)

        try:
            confirm = wait.until(EC.presence_of_element_located(
                (By.XPATH, "//*[contains(@id,'headlessui-dialog-panel')]//li//span")
            ))
            self.assertFalse(
                confirm.is_displayed(),
                "BUG-002 reproduit : quantité 1002 acceptée sans contrôle"
            )
        except TimeoutException:
            print("[TC-006] BUG-002 NON reproduit : quantité 1002 refusée")


if __name__ == '__main__':
    unittest.main(verbosity=2)
