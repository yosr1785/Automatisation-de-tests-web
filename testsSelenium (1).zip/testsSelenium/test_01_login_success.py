"""
=========================================================================
TC-001 [F-01] - Connexion avec identifiants valides
Statut attendu : PASS

Lancement :
    pytest test_01_login_success.py -v
=========================================================================
"""

import time
import unittest

from base import BaseTest


class Test01LoginSuccess(BaseTest):

    def test_01_login_success(self):
        driver = self.driver
        self.login()
        self.assertNotIn("login", driver.current_url.lower(),
                         "La redirection n'a pas eu lieu après connexion")

        driver.delete_all_cookies()
        driver.execute_script("window.localStorage.clear();")
        driver.execute_script("window.sessionStorage.clear();")
        time.sleep(1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
