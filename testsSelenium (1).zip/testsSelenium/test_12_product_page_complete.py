"""
=========================================================================
TC-012 [F-05] - Affichage complet d'une fiche produit
Statut attendu : PASS

Lancement :
    pytest test_12_product_page_complete.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test12ProductPageComplete(BaseTest):

    def test_12_product_page_complete(self):
        driver = self.driver
        wait   = self.wait
        PAUSE  = 2

        # ── 1. Navigation vers la fiche produit ───────────────────────────
        print("\n[TC-012] Navigation vers la fiche produit Baklawa el Bey...")
        driver.get("https://patisserieaicha.tn/product/55458/baklawa/409547/baklawa-el-bey/")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "h1")))
        time.sleep(PAUSE)

        # ── 2. Vérification du titre ──────────────────────────────────────
        print("[TC-012] Vérification du titre produit...")
        title = driver.find_element(By.TAG_NAME, "h1")
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", title)
        time.sleep(1)
        self.assertGreater(
            len(title.text.strip()), 0,
            "BUG : Titre du produit vide ou absent"
        )
        print(f"[TC-012] ✓ Titre : {title.text.strip()}")

        # ── 3. Vérification des images ────────────────────────────────────
        print("[TC-012] Vérification des images produit...")
        images = driver.find_elements(
            By.XPATH,
            "//img[contains(@src,'storage') or contains(@src,'upload') or contains(@src,'media')]"
        )
        if not images:
            images = driver.find_elements(By.XPATH, "//main//img[@src and string-length(@src) > 0]")
        if not images:
            images = driver.find_elements(By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]//img')

        self.assertGreater(len(images), 0, "BUG : Aucune image produit affichée")
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", images[0])
        time.sleep(1)
        print(f"[TC-012] ✓ {len(images)} image(s) trouvée(s)")

        # ── 4. Vérification du prix ───────────────────────────────────────
        print("[TC-012] Vérification du prix...")
        price = wait.until(EC.presence_of_element_located(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[3]')
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", price)
        time.sleep(1)
        self.assertGreater(
            len(price.text.strip()), 0,
            "BUG : Prix non affiché sur la fiche produit"
        )
        print(f"[TC-012] ✓ Prix : {price.text.strip()}")

        # ── 5. Vérification de la description ─────────────────────────────
        print("[TC-012] Vérification de la description produit...")
        description = wait.until(EC.presence_of_element_located(
            (By.XPATH,
             "//*[contains(@class,'description') or contains(@class,'desc')"
             " or contains(@class,'product-detail')]")
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", description)
        time.sleep(1)
        self.assertGreater(
            len(description.text.strip()), 0,
            "BUG : Description produit vide ou absente"
        )
        print(f"[TC-012] ✓ Description présente ({len(description.text.strip())} caractères)")

        # ── 6. Vérification du bouton quantité (+) ────────────────────────
        print("[TC-012] Vérification du bouton quantité...")
        qty_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//button[contains(text(),'+')]")
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", qty_btn)
        time.sleep(1)
        self.assertTrue(qty_btn.is_displayed(), "BUG : Bouton quantité (+) non disponible")
        print("[TC-012] ✓ Bouton quantité (+) disponible")

        # ── 7. Vérification du bouton "Ajouter au panier" ─────────────────
        print("[TC-012] Vérification du bouton Ajouter au panier...")
        add_btn = wait.until(EC.presence_of_element_located(
            (By.XPATH,
             '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[5]/div[2]/button')
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", add_btn)
        time.sleep(1)
        self.assertTrue(add_btn.is_displayed(), "BUG : Bouton 'Ajouter au panier' absent")
        print(f"[TC-012] ✓ Bouton panier présent : '{add_btn.text.strip()}'")

        time.sleep(PAUSE)
        print(f"\n[TC-012] ✓ Fiche produit complète : {title.text.strip()}")


if __name__ == '__main__':
    unittest.main(verbosity=2)
