"""
=========================================================================
TC-007 [F-02] - Mise à jour du panier vide tout (BUG-003)
Statut attendu : FAIL (le panier est entièrement vidé)

Lancement :
    pytest test_07_update_cart_empties.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test07UpdateCartEmpties(BaseTest):

    def test_07_update_cart_empties(self):
        driver = self.driver
        wait   = self.wait
        PAUSE  = 2

        self.login()

        # ── Ajout produit n°1 ─────────────────────────────────────────────
        print("\n[TC-007] Navigation vers produit 1...")
        driver.get("https://patisserieaicha.tn/product/55458/baklawa/409547/baklawa-el-bey")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "h1")))
        time.sleep(PAUSE)

        print("[TC-007] Clic Ajouter au panier - Produit 1...")
        btn1 = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[5]/div[2]/button')
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn1)
        time.sleep(PAUSE)
        driver.execute_script("arguments[0].click();", btn1)
        time.sleep(PAUSE * 2)

        # ── Ajout produit n°2 ─────────────────────────────────────────────
        print("[TC-007] Navigation vers produit 2...")
        driver.get("https://patisserieaicha.tn/product/55458/baklawa/409803/baklawa-noisette-amande")
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "h1")))
        time.sleep(PAUSE)

        print("[TC-007] Clic Ajouter au panier - Produit 2...")
        btn2 = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div[1]/div/div/div/div/div[2]/div/div[5]/div[2]/button')
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn2)
        time.sleep(PAUSE)
        driver.execute_script("arguments[0].click();", btn2)
        time.sleep(PAUSE * 2)

        # ── Aller sur la page panier ───────────────────────────────────────
        print("[TC-007] Navigation vers le panier...")
        driver.get(self.cart_url)
        wait.until(EC.url_contains("cart"))
        time.sleep(PAUSE * 2)

        # ── Modifier la quantité ───────────────────────────────────────────
        print("[TC-007] Clic sur + pour augmenter la quantité...")
        qty_btn = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, ".cart-item-increment-button")
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", qty_btn)
        time.sleep(PAUSE)
        driver.execute_script("arguments[0].click();", qty_btn)
        time.sleep(PAUSE)

        # ── Mettre à jour le panier ────────────────────────────────────────
        print("[TC-007] Clic sur Mettre à jour le panier...")
        update_btn = wait.until(EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="__nuxt"]/main/div/div/div/div/section[1]/div/button')
        ))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", update_btn)
        time.sleep(PAUSE)
        driver.execute_script("arguments[0].click();", update_btn)
        time.sleep(PAUSE * 2)

        # ── Assertion ──────────────────────────────────────────────────────
        print("[TC-007] Vérification du contenu du panier...")
        page_src = driver.page_source.lower()
        self.assertNotIn(
            "vide",
            page_src,
            "BUG-003 reproduit : le panier est vidé après mise à jour"
        )
        print("[TC-007] ✓ OK : le panier n'est pas vidé après mise à jour")


if __name__ == '__main__':
    unittest.main(verbosity=2)
