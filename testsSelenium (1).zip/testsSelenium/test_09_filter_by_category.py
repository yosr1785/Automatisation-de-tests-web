"""
=========================================================================
TC-009 [F-03] - Filtrage par catégorie
Statut attendu : PASS

Lancement :
    pytest test_09_filter_by_category.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from base import BaseTest


class Test09FilterByCategory(BaseTest):

    def test_09_filter_by_category(self):
        driver = self.driver
        wait   = self.wait
        PAUSE  = 1.5

        # ── 1. Navigation vers la catégorie Baklawa ────────────────────────
        print("\n[TC-009] Navigation vers la catégorie Baklawa...")
        driver.get("https://patisserieaicha.tn/product-list/55458/baklawa/")
        wait.until(EC.presence_of_element_located(
            (By.XPATH, "//*[contains(@class,'product')]")
        ))
        time.sleep(PAUSE)

        # ── 2. Tentative de clic sur le filtre grille ──────────────────────
        print("[TC-009] Recherche du filtre grille...")
        try:
            grid_filter = wait.until(EC.element_to_be_clickable(
                (By.XPATH,
                "//*[contains(@class,'grid') or contains(@class,'filter-grid')"
                " or contains(@class,'category-filter') or contains(@class,'fa-th')]")
            ))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", grid_filter)
            time.sleep(PAUSE)
            grid_filter.click()
            print("[TC-009] Filtre grille appliqué")
            time.sleep(PAUSE)
        except TimeoutException:
            print("[TC-009] Filtre grille non trouvé – vérification du contenu seul")

        # ── 3. Récupération des produits ───────────────────────────────────
        print("[TC-009] Récupération des produits affichés...")
        time.sleep(PAUSE)
        products = driver.find_elements(
            By.XPATH,
            "//*[contains(@class,'product') and "
            "(contains(@class,'item') or contains(@class,'card'))]"
        )
        print(f"[TC-009] {len(products)} produit(s) trouvé(s)")
        time.sleep(PAUSE)

        # ── 4. Assertions ──────────────────────────────────────────────────
        self.assertGreater(len(products), 0, "Aucun produit après filtrage")
        self.assertIn("baklawa", driver.current_url.lower(),
                      "Le filtre n'a pas appliqué la catégorie attendue")

        print(f"[TC-009] ✓ {len(products)} produits dans la catégorie Baklawa")


if __name__ == '__main__':
    unittest.main(verbosity=2)
