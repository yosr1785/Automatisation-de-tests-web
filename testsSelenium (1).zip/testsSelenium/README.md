# Tests automatisés - Pâtisserie Aïcha
**Projet :** Test Logiciel (ISTQB) - CI1 - FSB, Université de Carthage  
**Encadrante :** Mme Mariem Haoues  
**Année universitaire :** 2024 - 2025

---

## Structure du projet

```
patisserie_tests/
│
├── base.py                          # Classe de base partagée (setup, teardown, login, logout)
│
├── test_01_login_success.py         # TC-001 [F-01] Connexion valide → PASS
├── test_02_brute_force.py           # TC-002 [F-01] Brute force sans blocage (BUG-001) → FAIL
├── test_03_register_existing_email.py # TC-003 [F-01] Email déjà utilisé → PASS
├── test_05_add_to_cart.py           # TC-005 [F-02] Ajout au panier → PASS
├── test_06_quantity_unlimited.py    # TC-006 [F-02] Quantité illimitée (BUG-002) → FAIL
├── test_07_update_cart_empties.py   # TC-007 [F-02] Mise à jour vide le panier (BUG-003) → FAIL
├── test_08_search_functionality.py  # TC-008 [F-03] Recherche par mot-clé → PASS
├── test_09_filter_by_category.py    # TC-009 [F-03] Filtrage par catégorie → PASS
├── test_10_sort_by_price_asc.py     # TC-010 [F-03] Tri par prix croissant → PASS
├── test_11_footer_broken_link.py    # TC-011 [F-04] Lien footer cassé (BUG-005) → FAIL
└── test_12_product_page_complete.py # TC-012 [F-05] Fiche produit complète → PASS
```

---

## Lancement

### Un seul test
```bash
pytest test_01_login_success.py -v
pytest test_05_add_to_cart.py -v
pytest test_11_footer_broken_link.py -v
```

### Tous les tests
```bash
pytest -v
```

### Avec unittest directement
```bash
python test_01_login_success.py
python test_05_add_to_cart.py
```

---

## Prérequis
- Python 3.x
- selenium
- pytest
- ChromeDriver compatible avec votre version de Chrome
