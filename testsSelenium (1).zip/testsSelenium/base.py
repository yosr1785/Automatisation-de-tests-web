"""
=========================================================================
Classe de base partagée - Pâtisserie Aïcha
=========================================================================
Projet : Test Logiciel (ISTQB) - CI1 - FSB, Université de Carthage
Encadrante : Mme Mariem Haoues
Année universitaire : 2024 - 2025
=========================================================================
"""

import time
import unittest

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


class BaseTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(30)
        cls.driver.maximize_window()
        cls.wait = WebDriverWait(cls.driver, 15)

        cls.base_url            = "https://patisserieaicha.tn/"
        cls.login_url           = "https://patisserieaicha.tn/login"
        cls.register_url        = "https://patisserieaicha.tn/register"
        cls.cart_url            = "https://patisserieaicha.tn/cart"
        cls.forget_password_url = "https://patisserieaicha.tn/forget-password"

        cls.email    = "oumema.mechergui@fsb.ucar.tn"
        cls.password = "b"

        cls.driver.get(cls.base_url)

    @classmethod
    def tearDownClass(cls):
        try:
            cls.driver.quit()
        except Exception:
            pass

    def login(self):
        driver = self.driver
        wait   = self.wait

        driver.get(self.login_url)
        email_field = wait.until(EC.presence_of_element_located((By.NAME, "email")))

        email_field.clear()
        time.sleep(0.5)
        for char in self.email:
            email_field.send_keys(char)
            time.sleep(0.1)

        password_field = driver.find_element(By.NAME, "password")
        password_field.clear()
        for char in self.password:
            password_field.send_keys(char)
            time.sleep(0.05)

        time.sleep(2)

        btn = wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "button[type='submit']")
        ))
        driver.execute_script("arguments[0].click();", btn)
        time.sleep(5)

    def _logout(self):
        self.driver.delete_all_cookies()
        self.driver.execute_script("window.localStorage.clear();")
        self.driver.execute_script("window.sessionStorage.clear();")
        time.sleep(1)
