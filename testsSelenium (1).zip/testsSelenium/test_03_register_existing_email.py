"""
=========================================================================
TC-003 [F-01] - Inscription avec email déjà utilisé
Statut attendu : PASS (message d'erreur correct)

Lancement :
    pytest test_03_register_existing_email.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test03RegisterExistingEmail(BaseTest):

    def test_03_register_existing_email(self):
        driver = self.driver
        wait   = self.wait

        driver.get(self.register_url)
        time.sleep(3)

        wait.until(EC.presence_of_element_located((By.ID, "first_name"))).send_keys("Test")
        driver.find_element(By.ID, "last_name").send_keys("User")
        driver.find_element(By.ID, "email").send_keys(self.email)
        driver.find_element(By.ID, "phone").send_keys("25750407")
        driver.find_element(By.ID, "phone_extra").send_keys("25750407")
        driver.find_element(By.ID, "password").send_keys("Test1234@")
        driver.find_element(By.ID, "password2").send_keys("Test1234@")

        btn = wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "button[type='submit']")
        ))
        driver.execute_script("arguments[0].click();", btn)

        error = wait.until(EC.presence_of_element_located(
            (By.XPATH, "//*[contains(@class,'error') or contains(@class,'alert')]")
        ))
        self.assertTrue(
            "déjà"    in error.text.lower()
            or "already" in error.text.lower()
            or "existe"  in error.text.lower()
            or "exist"   in error.text.lower(),
            f"Message d'erreur attendu non trouvé. Reçu : {error.text}"
        )
        print(f"[TC-003] Email déjà utilisé refusé : {error.text}")


if __name__ == '__main__':
    unittest.main(verbosity=2)
