"""
=========================================================================
TC-011 [F-04] - Lien "Retours & Échanges" cassé (BUG-005)
Statut attendu : FAIL (page 404)

Lancement :
    pytest test_11_footer_broken_link.py -v
=========================================================================
"""

import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from base import BaseTest


class Test11FooterBrokenLink(BaseTest):

    def test_11_footer_broken_link(self):
        driver = self.driver
        wait   = self.wait

        # ── 1. Aller sur la page d'accueil ────────────────────────────────
        print("\n[TC-011] Navigation vers la page d'accueil...")
        driver.get(self.base_url)
        time.sleep(2)

        # ── 2. Scroller jusqu'au footer ───────────────────────────────────
        print("[TC-011] Défilement vers le footer...")
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)

        # ── 3. Trouver et mettre en évidence le lien ──────────────────────
        print("[TC-011] Recherche du lien 'Retours'...")
        link = wait.until(EC.element_to_be_clickable(
            (By.PARTIAL_LINK_TEXT, "Retours")
        ))
        driver.execute_script(
            "arguments[0].style.border='3px solid red'; "
            "arguments[0].scrollIntoView({block:'center'});",
            link
        )
        href = link.get_attribute("href")
        print(f"[TC-011] Lien trouvé : {href}")
        time.sleep(2)

        # ── 4. Cliquer sur le lien ─────────────────────────────────────────
        print("[TC-011] Clic sur le lien...")
        link.click()
        time.sleep(3)

        # ── 5. Vérifier qu'on est sur une page d'erreur 404 ───────────────
        final_url = driver.current_url
        page_src  = driver.page_source.lower()
        print(f"[TC-011] URL après clic : {final_url}")

        is_404 = (
            "404"                 in page_src
            or "page non trouvée" in page_src
            or "page not found"   in page_src
            or "introuvable"      in page_src
            or "/404"             in final_url
        )

        # ── 6. Assertion — doit FAIL pour signaler le bug ─────────────────
        self.assertFalse(
            is_404,
            f"BUG-005 DÉTECTÉ : le lien '{href}' mène vers une page 404 ({final_url})\n"
            f"Attendu : une page Retours & Échanges fonctionnelle"
        )

        print("[TC-011] ✓ Page Retours accessible (pas de 404)")


if __name__ == '__main__':
    unittest.main(verbosity=2)
